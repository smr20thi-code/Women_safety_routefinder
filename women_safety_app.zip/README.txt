
Women Safety Route Finder - Streamlit App
-----------------------------------------

Files:
- app.py : Streamlit application
- roads.json : sample dataset
- requirements.txt : python dependencies

Run locally:
1. python -m venv venv
2. source venv/bin/activate   # (Windows: venv\Scripts\activate)
3. pip install -r requirements.txt
4. streamlit run app.py

To deploy:
- Push this folder to GitHub and deploy on Streamlit Cloud, or deploy to any platform supporting Python apps.
