
import streamlit as st
import json
import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd

st.set_page_config(page_title="Women Safety Route Finder", layout="wide")
st.title("Women Safety Route Finder")
st.markdown("Compute the **safest** path between two nodes using safety-weighted graph search (Python + NetworkX).")

def load_graph_from_json(data):
    G = nx.Graph()
    for n in data.get("nodes", []):
        G.add_node(n)
    for e in data.get("edges", []):
        u, v = e["u"], e["v"]
        dist = float(e.get("distance", 1.0))
        safety = float(e.get("safety", 0.5))
        penalty = float(e.get("penalty", 5.0))
        weight = dist + (1.0 - safety) * penalty
        G.add_edge(u, v, distance=dist, safety=safety, weight=weight)
    return G

def compute_safest_path(G, source, target):
    try:
        path = nx.shortest_path(G, source=source, target=target, weight="weight")
        length = nx.shortest_path_length(G, source=source, target=target, weight="weight")
        return path, length
    except nx.NetworkXNoPath:
        return None, None
    except Exception as ex:
        st.error(f"Error computing path: {ex}")
        return None, None

def plot_graph(G, path=None):
    pos = nx.spring_layout(G, seed=42)
    fig, ax = plt.subplots(figsize=(7, 5))
    nx.draw_networkx_nodes(G, pos, node_size=400, node_color='lightblue', ax=ax)
    edges = G.edges(data=True)
    edge_colors = []
    widths = []
    for u, v, attr in edges:
        s = attr.get('safety', 0.5)
        cmap_val = (1.0 - s)
        edge_colors.append((cmap_val, 0.2, 1 - cmap_val))
        widths.append(1.5 + (1.0 - s) * 3)
    nx.draw_networkx_edges(G, pos, edgelist=G.edges(), edge_color=edge_colors, width=widths, ax=ax)
    nx.draw_networkx_labels(G, pos, font_size=9, ax=ax)
    if path:
        path_edges = list(zip(path, path[1:]))
        nx.draw_networkx_edges(G, pos, edgelist=path_edges, edge_color='gold', width=4, ax=ax)
        nx.draw_networkx_nodes(G, pos, nodelist=path, node_color='orange', node_size=450, ax=ax)
    ax.set_axis_off()
    st.pyplot(fig)

st.sidebar.header("Dataset")
data_option = st.sidebar.selectbox("Choose dataset", ["Sample dataset (provided)", "Upload JSON file"])
if data_option == "Upload JSON file":
    uploaded = st.sidebar.file_uploader("Upload roads.json", type=["json"])
    if uploaded:
        try:
            data = json.load(uploaded)
        except Exception as e:
            st.error("Invalid JSON file.")
            st.stop()
    else:
        data = None
else:
    sample_json = {
        "nodes": ["A", "B", "C", "D", "E", "F"],
        "edges": [
            {"u":"A","v":"B","distance":1.0,"safety":0.9},
            {"u":"B","v":"C","distance":1.2,"safety":0.6},
            {"u":"A","v":"D","distance":2.0,"safety":0.8},
            {"u":"D","v":"E","distance":1.0,"safety":0.95},
            {"u":"E","v":"C","distance":1.5,"safety":0.7},
            {"u":"B","v":"E","distance":2.0,"safety":0.4},
            {"u":"C","v":"F","distance":2.5,"safety":0.9}
        ]
    }
    data = sample_json
    st.sidebar.markdown("Using sample dataset. (You can upload your own JSON.)")

if not data:
    st.info("Upload a valid roads JSON or select the sample dataset.")
    st.stop()

G = load_graph_from_json(data)

st.sidebar.header("Settings")
penalty = st.sidebar.slider("Safety penalty (higher -> safety prioritized)", 0.0, 20.0, 5.0, step=0.5)
for u, v, attr in G.edges(data=True):
    dist = attr.get("distance", 1.0)
    safety = attr.get("safety", 0.5)
    attr["weight"] = dist + (1.0 - safety) * penalty

nodes = sorted(G.nodes())
col1, col2 = st.columns([1, 2])
with col1:
    st.subheader("Route Input")
    source = st.selectbox("Source", nodes, index=0)
    target = st.selectbox("Destination", nodes, index=len(nodes)-1)
    find_btn = st.button("Find Safest Route")
    st.write("---")
    st.subheader("Edit edge safety (optional)")
    rows = []
    for u, v, d in G.edges(data=True):
        rows.append({"u": u, "v": v, "distance": d.get("distance",1.0), "safety": d.get("safety",0.5)})
    df = pd.DataFrame(rows)
    edited = st.experimental_data_editor(df, num_rows='dynamic')
    if st.button("Apply edited safety values"):
        for idx, row in edited.iterrows():
            u, v = row['u'], row['v']
            s = float(row['safety'])
            dist = float(row.get('distance', 1.0))
            if G.has_edge(u, v):
                G[u][v]['safety'] = s
                G[u][v]['distance'] = dist
                G[u][v]['weight'] = dist + (1.0 - s) * penalty
        st.success("Updated edge safety values.")

with col2:
    st.subheader("Graph Visualization")
    plot_graph(G)

if find_btn:
    with st.spinner("Computing safest route..."):
        path, cost = compute_safest_path(G, source, target)
    if path is None:
        st.error("No path found between selected nodes.")
    else:
        st.success("Safest route found.")
        st.write("**Route:**", " → ".join(path))
        st.write(f"**Safety-weighted cost:** {cost:.3f}")
        safeties = []
        for a, b in zip(path, path[1:]):
            d = G[a][b]
            safeties.append(d.get('safety', 0.0))
        avg_safety = sum(safeties)/len(safeties) if safeties else 0
        st.write(f"**Average safety along route:** {avg_safety:.3f}")
        st.write("**Segment details:**")
        segs = []
        for a, b in zip(path, path[1:]):
            e = G[a][b]
            segs.append({'from': a, 'to': b, 'distance': e['distance'], 'safety': e['safety'], 'weight': e['weight']})
        st.table(pd.DataFrame(segs))
        st.subheader("Route on graph")
        plot_graph(G, path=path)
